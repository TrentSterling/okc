PRAIRIE PRISM
Reconstruction captures

10 original canvas PNGs from the Three.js application.
PNG bytes are copied unchanged. These are rendered scene captures.

shots.json preserves each image's camera, scene settings, dimensions,
capture source revision, and capture date where originally recorded.
Some development images have no individual source revision or date.
The sourceManifest entry identifies the combined gallery manifest.
Current live geometry can include fixes made after these photographs.

A current image with a viewId can be opened with ?view=<viewId>.
Earlier images retain their original pixels and have no exact live replay.

This is a mapped visual reconstruction, with estimated heights and facade
details, authored lighting, illustrative planting, and flat terrain.
It is not a surveyed digital twin. The crown display is independent of
the reflected sunset.

Geographic attribution: see GEOGRAPHIC-NOTICE.txt. Source details:
https://tront.xyz/okc/geo/provenance.json

Scene: https://tront.xyz/okc/
Gallery: https://tront.xyz/okc/gallery/
Repository: https://github.com/TrentSterling/okc
